# SQLite-Example
Ejemplo de SQLite (Android).
Proyecto realizado en Android 5.1.0. API 22
