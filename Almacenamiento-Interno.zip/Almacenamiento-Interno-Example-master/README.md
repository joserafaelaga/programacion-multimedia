# Almacenamiento-Interno-Example
Ejemplo de Almacenamiento Interno (Android). Proyecto realizado en Android 5.1.0. API 22
