# Captura-Fotografias-Android
Ejemplo de captura de fotografías en Android. Proyecto realizado en Android 5.1.0. API 22
