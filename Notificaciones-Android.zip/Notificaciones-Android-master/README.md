# Notificaciones-Android
Ejemplo de notificaciones en Android. Proyecto realizado para Android 5.1.0. API 22
