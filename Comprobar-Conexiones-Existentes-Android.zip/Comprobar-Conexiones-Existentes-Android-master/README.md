# Comprobar-Conexiones-Existentes-Android
Ejemplo de comprobación de conexiones existentes. Proyecto realizado para Android 5.1.0. API 22
