# Grabacion-Video-Android
Ejemplo de grabación de vídeo en Android. Proyecto realizado para Android 5.1.0. API 22
