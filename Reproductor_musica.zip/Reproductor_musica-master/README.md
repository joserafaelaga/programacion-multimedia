# Reproductor_musica
Ejemplo de reproducción de audio (Android). Proyecto realizado en Android 5.1.0. API 22
