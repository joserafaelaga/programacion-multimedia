# grabadora_audio
Ejemplo de grabación y reproducción de audio (Android). Proyecto realizado en Android 5.1.0. API 22
